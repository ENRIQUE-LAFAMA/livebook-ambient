<?php

$conexion = mysqli_connect("localhost", "root", "","base_livebook");

if (!$conexion){
    echo 'Error al conectar a la base de datos';
}
else{
    echo '';
    
}

?>
<?php

include("conet.php");
$id = $_GET['id'];
$eliminar = "DELETE FROM libros WHERE id = '$id'";

$resultado = mysqli_query($conexion, $eliminar);
if($resultado){
    echo "<script>alert('LIBRO ELIMINADO'); window.history.go(-1);</script>";
    header("location:../panel/eliminarLibro.php");
}
else{
    echo "<script>alert('No fue posible eliminar este Libro'); window.history.go(-1);</script>";
}







?>
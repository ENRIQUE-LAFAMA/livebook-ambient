<?php



/*

if(isset($_POST['submit'])){
    if(empty($nombre)){
        echo "<p class= 'error'> * Falta el nombre</p>";
    }
    else {
        if(strlen($nombre) > 15){
            echo "<p class= 'error'> * El nombre es muy largo</p>";
        }
    }
    if(empty($apellidos)){
        echo "<p class= 'error'> * Falta el apellido</p>";
    }
    else {
        if(strlen($apellidos) > 15){
            echo "<p class= 'error'> * El apellido es muy largo</p>";
        }
    }
    if(empty($tel)){
        echo "<p class= 'error'> * Falta el telefono</p>";
    }
    else {
        if(!is_numeric($tel)){
            echo "<p class= 'error'> * Inserte un numero valido</p>";
        }
    }
    if(empty($correo)){
        echo "<p class= 'error'> * Falta el correo</p>";
    }
    else {
        if(!filter_var($correo, FILTER_VALIDATE_EMAIL)){
            echo "<p class= 'error'> * El correo no es valido</p>";
        }
    }
    
    if(empty($password)){
        echo "<p class= 'error'> * Falta el password</p>";
    }
}
*/

?>
<?php

include ("conet.php");
$agregar= mysqli_query($conexion,"INSERT INTO rol (id, rol) values ('3','superAdmin')");

?>



<?php require_once "vistas/arriba.php";?>
 
<div class="container">
    <h1>hola</h1>
</div>

<?php require_once "vistas/bajo.php";?>